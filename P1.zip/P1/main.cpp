#include "matlab.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    //aufgaben_string[100];
    QApplication a(argc, argv);
    Matlab w;
    w.show();

    return a.exec();
}
