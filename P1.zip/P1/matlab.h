#ifndef MATLAB_H
#define MATLAB_H

#include <QWidget>

namespace Ui {
class Matlab;
}

class Matlab : public QWidget
{
    Q_OBJECT

public:
    char aufgaben_string[100];

    int number[10];
    char oper[10];

    // Arrays werden deklariert

    explicit Matlab(QWidget *parent = 0);
    ~Matlab();

private slots:
    void on_Ziffer1_clicked();

    void on_Ziffer2_clicked();

    void on_Ziffer5_clicked();

    void on_Ziffer3_clicked();

    void on_Ziffer4_clicked();

    void on_Ziffer6_clicked();

    void on_Ziffer7_clicked();

    void on_Ziffer8_clicked();

    void on_Ziffer9_clicked();

    void on_Ziffer0_clicked();

    void on_SymAddieren_clicked();

    void on_SymSubtrahieren_clicked();

    void on_SymMultiplizieren_clicked();

    void on_SymDividieren_clicked();

    void on_SymModulo_clicked();

    void on_SymPotenz_clicked();

    void on_SymLoesen_clicked();

    void on_SymLoeschen_clicked();

    // Funktionen werden dklariert

private:
    Ui::Matlab *ui;

};

#endif // MATLAB_H
