#include "matlab.h"
#include "ui_matlab.h"
#include <stdio.h>
#include <string.h>
#include <cstdlib>
#include <vector>
#include <iostream>

using namespace std ;

int zahlc = 0;
int ergebnis = 0;
int i = 0;
int index = 0;

//Hier werden die Variablen initialisiert

Matlab::Matlab(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Matlab)



{
    ui->setupUi(this);
}

Matlab::~Matlab()
{
    delete ui;
}

void Matlab::on_Ziffer1_clicked()
{
    aufgaben_string[i] = '1';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer2_clicked()
{
    aufgaben_string[i] = '2';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer3_clicked()
{
    aufgaben_string[i] = '3';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer4_clicked()
{
    aufgaben_string[i] = '4';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer5_clicked()
{
    aufgaben_string[i] = '5';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer6_clicked()
{
    aufgaben_string[i] = '6';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer7_clicked()
{
    aufgaben_string[i] = '7';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);;
}

void Matlab::on_Ziffer8_clicked()
{
    aufgaben_string[i] = '8';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer9_clicked()
{
    aufgaben_string[i] = '9';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

void Matlab::on_Ziffer0_clicked()
{
    aufgaben_string[i] = '0';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

// Hier werden die Funktionen ausgeführt die beschreiben was passiert, wenn man auf die Zahlentasten drückt

void Matlab::on_SymAddieren_clicked()
{
    aufgaben_string[i] = ' ';
    i=i+1;
    aufgaben_string[i] = '+';
    i=i+1;
    aufgaben_string[i] = ' ';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

// Funktion die ausgeführt wird, wenn man den "+" Button drückt

void Matlab::on_SymSubtrahieren_clicked()
{
    aufgaben_string[i] = ' ';
    i=i+1;
    aufgaben_string[i] = '-';
    i=i+1;
    aufgaben_string[i] = ' ';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}

// Funktion die ausgeführt wird, wenn man den "-" Button drückt

void Matlab::on_SymMultiplizieren_clicked()
{
    aufgaben_string[i] = ' ';
    i=i+1;
    aufgaben_string[i] = '*';
    i=i+1;
    aufgaben_string[i] = ' ';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}
// Funktion die ausgeführt wird, wenn man den "*" Button drückt

void Matlab::on_SymDividieren_clicked()
{
    aufgaben_string[i] = ' ';
    i=i+1;
    aufgaben_string[i] = '/';
    i=i+1;
    aufgaben_string[i] = ' ';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}
// Funktion die ausgeführt wird, wenn man den "/" Button drückt
void Matlab::on_SymModulo_clicked()
{
    aufgaben_string[i] = ' ';
    i=i+1;
    aufgaben_string[i] = '%';
    i=i+1;
    aufgaben_string[i] = ' ';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}
// Funktion die ausgeführt wird, wenn man den "%" Button drückt
void Matlab::on_SymPotenz_clicked()
{
    aufgaben_string[i] = ' ';
    i=i+1;
    aufgaben_string[i] = '^';
    i=i+1;
    aufgaben_string[i] = ' ';
    i=i+1;
    ui->lineEdit->setText(aufgaben_string);
}
// Funktion die ausgeführt wird, wenn man den "^" Button drückt

// Am Ende wird die gesamte Aufgabe in dem "aufgabenstring" gespeichert

void Matlab::on_SymLoesen_clicked()
{
    int highest_priority = 1;

    std:: vector<int> numbers;
    std:: vector<char*> operators;
    int firstChar = 0;
    for ( i = 0; i < sizeof (aufgaben_string) / sizeof (char); i++) {
       if (aufgaben_string[i] == ' ') {
           char* string = new char[i - firstChar]();
           strncpy(string, &(aufgaben_string[firstChar]), i - firstChar);
           if (string[0] >= '0' && string[0] <= '9') {
               numbers.push_back(atoi(string));
           }

           else {
               operators.push_back(string);
           }
           firstChar = i + 1;
        }
    }
    // teilt "aufgabenstring" in Zahlen und Operatoren und speichert diese in zwei Vektoren ab.


    char string[sizeof (aufgaben_string) / sizeof (char) -firstChar];
    strncpy(string, &(aufgaben_string[firstChar]), sizeof (aufgaben_string) / sizeof (char) -firstChar);

    if (string[0] >= '0' && string[0] <= '9') {
        numbers.push_back(atoi(string));
    }

    else {
        operators.push_back(string);
    }
    // Sollte am Ende ein Space kommen wird die Aufgabe trotzdem ausgeführt

    int s = 0;
    while (!numbers.empty()){
        number[s]=numbers.back();
        s=s+1;
        numbers.pop_back();
     }

     s = 0;
     while (!operators.empty()){
        oper[s]=*operators.back();
        s=s+1;
        operators.pop_back();
     }



     while(highest_priority > 0){

         /* Als nächstes wird die Reihenfolge ermittelt, in der die Zahlen berechnet werden sollen. Dabei haben
            Multiplikation und Divison die höchste Priorität gefolgt von Modulo- /Potenzrechnung. Die niedrigste
            Priorität besitzen Addition und Subtraktion. Die Priorität wird zu Beginn =0 gesetzt, sodass die Schleife
            abbricht, sobald in der for-Schleife keine neue Priorität zugeordnet wird, was geschieht
            wenn das array oper keine Operatoren mehr enthällt.*/

         highest_priority = 0;

         for(int i=0; i<10; i++){

             if((oper[i] == '+' && highest_priority < 1 )|| (oper[i] == '-' && highest_priority < 1) ){
                 highest_priority = 1;
                 index = i;
             }

             if((oper[i] == '^' && highest_priority < 2) || (oper[i] == '%' && highest_priority < 2) ){
                 highest_priority = 2;
                 index = i;
             }

             if((oper[i] == '*' && highest_priority < 3) || (oper[i] == '/' && highest_priority < 3 )){
                 highest_priority = 3;
                 index = i;
             }
         }

         /* Die if-Funktion prüft die Operatoren an den einzelnen Stellen im Array und vergleicht um welche Art Opertor
         es sich handelt. Es wird dann die entsprechende Priorität zugewiesen und die Stelle von diesem "i" aus dem Array
         der Operatoren durch "index" gespeichert. Nachdem die for-schleife alle Werte aus dem Array "oper" durchlaufen
         hat, springt das Programm aus der for-Schleife.*/

         if(highest_priority == 3){

             if(oper[index] == '*' ){
                 zahlc = number[index+1] * number[index] ;
                 oper[index] = '0';
                 number[index] = zahlc;
                 number[index+1] = zahlc;
                 ergebnis = zahlc;
             }

             if(oper[index] == '/'){
                 zahlc = number[index+1] / number[index] ;
                 oper[index] = '0';
                 number[index] = zahlc;
                 number[index+1] = zahlc;
                 ergebnis = zahlc;
             }
         }

         if(highest_priority == 2){

             if(oper[index] == '%'){
                 zahlc = number[index+1] % number[index]  ;
                 oper[index] = '0';
                 number[index] = zahlc;
                 number[index+1] = zahlc;
                 ergebnis = zahlc;
             }

             if(oper[index] == '^'){
                 zahlc = 1;
                 for(int c = 0; c < number[index]; c++){
                     zahlc = zahlc * number[index+1] ;
                 }
                 oper[index] = '0';
                 number[index] = zahlc;
                 number[index+1] = zahlc;
                 ergebnis = zahlc;
             }

         }

         if(highest_priority == 1){

             if(oper[index] == '+'){
                 zahlc = number[index+1] + number[index] ;
                 oper[index] = '0';
                 number[index] = zahlc;
                 number[index+1] = zahlc;
                 ergebnis = zahlc;
             }

             if(oper[index] == '-'){
                 zahlc = number[index+1] - number[index] ;
                 oper[index] = '0';
                 number[index] = zahlc;
                 number[index+1] = zahlc;
                 ergebnis = zahlc;
             }

         }

    }
     /* Durch die folgenden if-Funktionen, prüft das Programm zunächst um welche Prioritäts-Stufe es sich handelt.
     Im Anschluss wird geprüft, um welchen operator es sich handelt.
     Dann beginnt die Rechnung. Die Variable "zahlc" ergibt sich aus der Berechnung der Zahl aus dem Array "number"
     an der Stelle "index" und der Stelle "index+1", sowie dem Operator aus der Stelle "index" des oper Arrays.
     Nach der Berechnung wird der operator oper[index] auf null gesetzt, damit dieser Teil der Aufgabe nicht nochmals berechnet wird.
     Die Zahlen aus dem Array "number" werden an der Stelle "index" und "index + 1" zu dem Ergebnis aus der vorherigen
     Berechnung. "ergebnis" nimmt immer den Wert der letzten Berechnung an. Nun beginnt die while-Schleife
     neu mit der ersten for-Schleife die erneut die Priorität ermittelt.
     Daraufhin wird durch die folgenden if-Funktionen die entsprechende berechnung mit dem entsprechenden Operatoren
     durchgeführt. "number index" und "number index + 1" werden wieder das Ergebnis dieser Berechnung. Ergebnis wird "zahlc"
     und der Operator wird auf 0 gesetzt. Dies geschieht solange bis alle Operatoren verwendet und auf
     0 gesetzt wurden. Die while schleife startet nicht mehr, da die Bedingung highest_priority > 0, nur solange erfüllt ist,
     wie die Priorität im vorigen for-schleifen Durchlauf verändert wurde. */

    ui->lcdNumber->display(ergebnis);
    for( i = 0; i < 100; i++){
        aufgaben_string[i] = 0;
    }

    for(i = 0; i < 5; i++){
        number[i] = 0;
        oper[i] = '0';
    }

    zahlc = 0;
    ergebnis = 0;
    i = 0;
    index = 0;
    ui->lineEdit->setText(aufgaben_string);
}

/*Alle Arrays und Variablen ( aufgaben_string; zahlc; ergebnis und index) werden wieder auf Null gesetzt
und durch die Funktion "display" das Ergebnis ausgegeben*/

void Matlab::on_SymLoeschen_clicked()
{


    for(i = 0; i < 100; i++){
        aufgaben_string[i] = 0;
    }

    for(i = 0; i < 10; i++){
        number[i] = 0;
        oper[i] = '0';
    }

    zahlc = 0;
    ergebnis = 0;
    i = 0;
    index = 0;
    ui->lineEdit->setText(aufgaben_string);
    ui->lcdNumber->display(ergebnis);
}
 //Hier werden die Variablen gelöscht ( möglicherweise bei der Eingabe)
